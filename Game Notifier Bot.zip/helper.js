// Meant to keep some extra's like functions to connect to our database
