// File that will handle the web-requests from games
